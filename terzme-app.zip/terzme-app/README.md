# TerzMe app
1. GitHub-da yeni repo aç, bu faylların hamısını (`.github` qovluğu daxil) yüklə, `main` branch-a push et.
2. Actions tabında "Android APK" işləyəndən sonra Releases bölməsindən `app-debug.apk` yüklə.
3. iOS: Mac-də `npm install && npx cap add ios && npx cap open ios` (Apple Developer hesabı lazımdır).
4. Play Store üçün imzalı AAB lazımdır (`./gradlew bundleRelease` + keystore).
